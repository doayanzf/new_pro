<template>
    <div id="toolBar">
        <i class="glyphicon glyphicon-plus"
            @click="add_note"
        ></i>
        <i class="glyphicon glyphicon-star"
            @click="fav_note"
            :class="{ favorite: activeNote.isFav }"
        >
        </i>
        <i class="glyphicon glyphicon-remove"
            @click="del_note"
        >
        </i>
    </div>
</template>
<script>
export default {
    data() {
        return {
            
        }
    },
    methods: {
        // 添加新日志
        add_note() {
            this.$store.dispatch('add_note')
        },
        // 收藏日志
        fav_note() {
            this.$store.dispatch('fav_note')
        },
        // 删除日志
        del_note() {
            this.$store.dispatch('del_note')
        }
    },
    computed: {
        // 获取当前激活日志
        activeNote() {
            return this.$store.getters.getActiveNote
        }
    }
}
</script>
<style type='text/css'>
#toolBar {
    float: left;
    width: 80px;
    height: 100%;
    background-color: #30414D;
    color: #767676;
    padding: 35px 25px 25px 25px;
}

#toolBar i {
    font-size: 30px;
    margin-bottom: 35px;
    cursor: pointer;
    opacity: .8;
    transition: all .5s;
}

#toolBar i:hover {
    opacity: 1;
}

.favorite {
    color: #F7AE4F;
}
</style>