<template>
    <div class="" id="todolist">
      <div class="list-header">
          <h2>日志列表</h2>
          <div class="btn-group" role="group" aria-label="...">
              <button type="button" 
                    class="btn btn-default" 
                    :class="{ active: type == 'all' }"
                    @click="type = 'all'"
                   >所有日志</button>
              <button type="button" 
                    class="btn btn-default" 
                    :class="{ active: type == 'fav' }"
                    @click="type = 'fav'"
                    >收藏日志</button>
          </div>
      </div>
      <div class="list-container">
          <ul class="list-group">
            <li class="list-group-item"
                v-for="note in noteList"
                :key="note.id"
                @click="activeFn(note)"
                :class="{ active: activeNote == note }"
            > 
                <h4 class="list-group-item-heading">
                    {{ note.name }}
                </h4>
            </li>
          </ul>
      </div>

  </div>
</template>
<script>
export default {
    data(){
        return {
            // all 表示 所有日志，fav 表示 收藏日志
            type: 'all'
        }
    },
    computed: {
        // 获取日志列表
        noteList() {
            if ( this.type == 'all' ) {
                return this.$store.getters.getNoteList
            } else {
                // 否则返回收藏日志列表
                return this.$store.getters.getFavNoteList
            }
            
        },
        // 获取当前激活日志
        activeNote() {
            return this.$store.getters.getActiveNote
        }
    },
    methods: {
        // 激活日志的方法
        activeFn(note) {
            this.$store.dispatch('active_note', note)
        }
    }
}
</script>
<style type='text/css'>
#todolist{
    float: left;
    width: 300px;
    height: 100%;
    background-color: #F5F5F5;
    font-family: 'Raleway', sans-serif;
    font-weight: 400;
}
.list-header{
    width: 100%;
    text-align: center;
}
.list-header h2 {
  font-weight: 300;
  text-transform: uppercase;
  text-align: center;
  font-size: 22px;
  padding-bottom: 8px;
}
.list-header button{
    width:120px;
}
.list-container{
    margin-top:30px;
}
.list-container h4{
    word-break:keep-all;           /* 不换行 */
    white-space:nowrap;          /* 不换行 */
    overflow:hidden;               /* 内容超出宽度时隐藏超出部分的内容 */
    text-overflow:ellipsis;
}

</style>