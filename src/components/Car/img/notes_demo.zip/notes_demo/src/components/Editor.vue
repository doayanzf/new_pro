<template>
    <div class="editor">
      <textarea v-model="activeNote.name"></textarea>
  </div>
</template>
<script>
export default {
    data() {
        return {

        }
    },
    computed: {
        // 获取当前激活日志
        activeNote() {
            return this.$store.getters.getActiveNote
        }
    }
}
</script>
<style type='text/css'>
.editor{
    /*float:left;*/
    height: 100%;
  margin-left: 380px;
}
.editor textarea {
    width:100%;
  height: 100%;
  border: 0;
  border-radius: 0;
  resize:none;
  padding:0;
  font-size : 32px;
}

</style>