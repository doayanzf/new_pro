<template>
  <div id="app">
    <tool-bar></tool-bar>
    <note-list></note-list>
    <editor></editor>
  </div>
</template>

<script>
import ToolBar from './components/ToolBar'
import NoteList from './components/NoteList'
import Editor from './components/Editor'

export default {
  name: 'App',
  components: {
    ToolBar,
    NoteList,
    Editor
  }
}
</script>

<style>
@import '../static/bootstrap/css/bootstrap.min.css';

html, #app {
  height: 100%;
}

body {
  overflow: hidden;

  margin: 0;
  padding: 0;
  border: 0;
  height: 100%;
  max-height: 100%;
  position: relative;
}
</style>
