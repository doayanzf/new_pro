import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        // 日志列表
        noteList: [],
        // 被激活的日志
        activeNote: {}
    },
    mutations: {
        // 添加日志
        ADD_NOTE(state) {
            var note = {
                name: '新日志',
                // 是否被收藏（默认新生成的是不收藏的）
                isFav: false
            }
            state.noteList.push(note)
            // 每次新添加的日志都设置为当前的激活对象
            state.activeNote = note
        },
        // 设置激活日志对象
        ACTIVE_NOTE(state, note) {
            state.activeNote = note
        },
        // 收藏日志
        FAV_NOTE(state) {
            // 就是收藏被激活日志对象
            state.activeNote.isFav = !state.activeNote.isFav
        },
        // 删除日志
        DEL_NOTE(state) {
            var idx = state.noteList.indexOf(state.activeNote)
            if (idx != -1) {
                state.noteList.splice(idx, 1)
                // 处理下收藏的默认样式
                state.activeNote = { isFav: false }
            }
        }
    },
    actions: {
        // 添加日志
        add_note(state) {
            state.commit('ADD_NOTE')
        },
        // 设置激活日志对象
        active_note(state, note) {
            state.commit('ACTIVE_NOTE', note)
        },
        // 收藏日志
        fav_note(state) {
            state.commit('FAV_NOTE')
        },
        // 删除日志
        del_note(state) {
            state.commit('DEL_NOTE')
        }
    },
    getters: {
        // 返回日志列表
        getNoteList(state) {
            return state.noteList
        },
        // 返回当前激活日志对象
        getActiveNote(state) {
            return state.activeNote
        },
        // 返回收藏日志列表
        getFavNoteList(state) {
            return state.noteList.filter( note => note.isFav )
        }
    }
})